<?php
/**
 * Page template.
 *
 * Purpose:
 * - Renders standard WordPress pages (when no custom page template is assigned).
 *
 * @package Nolan_Showcase_Theme_05
 */

get_header();
?>

<section class="section section--tight">
	<div class="container">
		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/content', 'page' );

			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
		endwhile;
		?>
	</div>
</section>

<?php
get_footer();
